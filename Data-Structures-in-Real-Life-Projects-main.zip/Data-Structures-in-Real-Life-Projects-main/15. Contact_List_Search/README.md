## Contact List Search


### Description
Add, remove and search for contacts.

### Skills nurtured:
Trie for optimized search.

### Tech. Stack:
HTML, CSS, JS
