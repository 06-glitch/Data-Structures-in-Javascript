## Photo Editor

https://user-images.githubusercontent.com/56497318/127525177-c5f99efa-f869-431e-a141-d4c29b8e009a.mp4



### Description
  - Functions:-
      - Upload and save photo, flip horizontal vertical, resize, rotate & greyscale.

### Skills nurtured:
  - 3D array to store rgb values of each pixel.
  - Learnt new concepts of RGB, Pixels and how its change affects the display.
  - Explored logics for different functions of editor.

### Tech. Stack:
HTML, CSS, JS, CANVAS
