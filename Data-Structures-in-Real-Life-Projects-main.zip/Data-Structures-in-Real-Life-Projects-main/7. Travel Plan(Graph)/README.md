## Travel Plan

https://user-images.githubusercontent.com/56497318/127523659-248b7f2f-e2ce-4623-880d-62fe46e52718.mp4




### Description
Find least time path between cities.

### Skills nurtured:
  - Graph.
  - Dijkstra's algorithm to find shortest time path.

### Tech. Stack:
HTML, CSS, JS, CANVAS

