
https://user-images.githubusercontent.com/56497318/127524563-8c7b6ead-0211-4c95-835c-1ca082f59834.mp4


## Text Editor
## Description
Write, Delete and Undo text operations.

## Skills nurtured:
Used Stack for undo functionality.

## Tech. Stack:
HTML, CSS, JS
