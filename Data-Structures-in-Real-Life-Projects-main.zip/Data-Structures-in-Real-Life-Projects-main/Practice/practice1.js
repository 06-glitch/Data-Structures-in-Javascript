class test{
    constructor(color, shape){
        this.color = color;
        this.shape = shape;
    }
};



var c = document.getElementById('my_canvas');
console.log(c);