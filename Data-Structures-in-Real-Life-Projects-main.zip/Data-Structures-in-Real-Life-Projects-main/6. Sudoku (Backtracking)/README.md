### Preview:
<p> In this Sudoku Web Application we implemented <b>Backtracking</b>.<br><br>
To build this game we used the JavaScript and Bootstrap.<br><br>
<b>Logics</b> and <b>Concepts</b> implemented in this game:<br></p>
<ul>
  <li>Backtracking</li>
  <li>Mathematics</li>
  <li>Buttons</li>
  <li> Dynamic and Static logic</li>
</ul>
    
###### This is how the game looks.
<img src="s1.PNG" alt="Trulli" width="700" height="500"><br><br><br>
