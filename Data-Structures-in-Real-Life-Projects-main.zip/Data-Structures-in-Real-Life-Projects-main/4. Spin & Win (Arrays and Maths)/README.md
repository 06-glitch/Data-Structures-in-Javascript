
### Spin & Win:
https://user-images.githubusercontent.com/56497318/127522189-e7cf005f-f309-45a3-8f7a-3d876a3866a1.mp4

<p> In this game we implemented <b>arrays</b> ds and used some mathematical concepts. <br><br>
To build this game we used the <b>'Phaser'</b> Framework.<br><br>
<b>Logics</b> and <b>Concepts</b> implemented in this game:<br></p>
<ul>
  <li> GameLoop in Phaser</li>
  <li> Adding Images</li>
  <li> Animations </li>
  <li> Arrays </li>
  <li> Mathematical concepts</li>
  <li> Adding Music</li>
  <li> OOPs </li>
</ul>
    

