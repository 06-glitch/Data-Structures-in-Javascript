

## Splitwise 
https://user-images.githubusercontent.com/56497318/127523960-86589587-376e-41a4-867d-805c6c7cf300.mp4


### Description
Simplifies dense cash flows

### Skills nurtured:
  - Heap & Graph.
  - Splitwise algorithm to remove unnecessary edges(cash flow) of graph.

### Tech. Stack:
HTML, CSS, JS, CANVAS
