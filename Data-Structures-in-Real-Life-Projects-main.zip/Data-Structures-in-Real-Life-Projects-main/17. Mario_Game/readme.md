## Mario





https://user-images.githubusercontent.com/56497318/127527665-54ae3ff2-7c0f-4595-bf49-3e628765f077.mp4




### Description
Help Mario to collect maximum coins.

### Skills nurtured:
  - Graph.
  - Used Dynamic Programming & Greedy Approach to get maximum coins at each level.

### Tech. Stack:
HTML, CSS, JS, CANVAS, PHASER
