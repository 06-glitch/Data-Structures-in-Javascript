## Covid Fighter




https://user-images.githubusercontent.com/56497318/127527373-b8613676-1f56-41f2-9015-4ed3a9a9d236.mp4


### Description
  - Help Hero dodge
  - corona viruses and aquire diamond.

### Skills nurtured:
  - Canvas API for UI design.
  - Maths logics to make player and enemy move with variant speed.

### Tech. Stack:
HTML, CSS, JS, CANVAS
