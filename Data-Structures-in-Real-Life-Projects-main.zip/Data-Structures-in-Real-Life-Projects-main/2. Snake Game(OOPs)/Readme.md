## Snake Game



https://user-images.githubusercontent.com/56497318/127527203-19455d98-c9e3-4766-991f-b1aa8e97973c.mp4



### Description
Help Snake to increase its size and score by eating apples.Game ends when Snake hits wall.

### Skills nurtured:
  - Canvas API for UI design
  - Arrays Data Structure & OOPs to build Snake and game functions.
  - Maths logics to build snake, randomly generate apple,  increase score etc.

### Tech. Stack:
HTML, CSS, JS, CANVAS
