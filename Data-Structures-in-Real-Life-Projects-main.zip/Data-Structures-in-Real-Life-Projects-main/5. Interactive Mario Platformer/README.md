### Preview:


https://user-images.githubusercontent.com/56497318/127526916-9572bdaf-db36-44c0-a616-88414770c0d6.mp4

<p> In this game we implemented <b>arrays</b> ds.<br><br>
To build this game we used the <b>'Phaser'</b> Framework.<br><br>
<b>Logics</b> and <b>Concepts</b> implemented in this game:<br></p>
<ul>
  <li> Physics Concepts</li>
  <ol>
    <li>Jump</li>
    <li>Bounce</li>
    <li>Gravity</li>
    <li>Speed</li>
  </ol>
  <li> How to use Keyboard for activity</li>
  <li> Animations </li>
  <li> Tweens(For moving sunrays effect in background using Arrays ds) </li>
  <li> Camera Control</li>
  <li> Dynamic and Static group logic</li>
  <li> Collision and Overlap logic</li>
</ul>
