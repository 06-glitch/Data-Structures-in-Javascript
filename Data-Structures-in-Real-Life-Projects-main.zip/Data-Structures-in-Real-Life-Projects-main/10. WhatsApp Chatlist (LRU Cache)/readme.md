## Whatsapp Chatlist

### Description
A chat application using Least Recently Used Cache. It provides insertion, deletion, and searching in constant time.

### Skills nurtured:
  - Caching concept.
  - LRU(Least Recently Used) Cache.
  - Linked List & defualt HashMaps.

### Tech. Stack:
HTML, CSS, JS
