## Jump Froggy



https://user-images.githubusercontent.com/56497318/127526872-921f4734-a3d6-4bff-95ed-0e0d3c1ceacb.mp4



### Description
Help Jack reach the destination in less moves.

### Skills nurtured:
Used Dynamic Programming & Greedy Approach to calculate minimum moves.

### Tech. Stack:
HTML, CSS, JS, PHASER
